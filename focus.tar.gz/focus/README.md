# Focus

A quiet, ADHD-aware focus tool. Self-hosted, single-user, accessed at `https://focus.baltito.com`.

## Architecture

- **Frontend:** SvelteKit PWA + Tailwind, dark warm aesthetic
- **Backend:** FastAPI + SQLAlchemy + SQLite
- **Auth:** Password (bcrypt) + optional TOTP 2FA. JWT cookie session.
- **LLM + STT:** Groq via OpenAI-compatible API
- **Reverse proxy:** Caddy with auto-HTTPS

No SMTP. No external auth dependencies. Backend container's only egress is to `api.groq.com`.

## ⚠️ OPSEC — read first

You are a federal employee. This tool is on a personally-owned VM and audio passes through Groq.

- **No case data anywhere.** Not in task titles, capture, or dictation.
- **Abstractions only:** ✅ `"Q3 inspection report"` ❌ `"HM Pharmacy Winnetka writeup"`.
- **Dictation is the highest risk surface.** Audio leaves your infra.
- Treat the tool like a public Trello board.

## First-time setup

```bash
git clone <repo> ~/focus && cd ~/focus
cp .env.example .env

# 1. Session secret — paste the output into .env as JWT_SECRET=...
openssl rand -hex 64

# 2. Password hash
pip install bcrypt
python3 bin/hash-password.py
#   prompts for password, prints AUTH_PASSWORD_HASH='...' line for .env

# 3. (Recommended) 2FA — drop AUTH_TOTP_SECRET into .env, scan URI into authenticator
pip install pyotp
python3 bin/setup-2fa.py

# 4. Groq key — grab at https://console.groq.com/keys, paste into LLM_API_KEY

nano .env  # fill in everything
```

## Deploy

```bash
# DNS first:  A record  focus.baltito.com  →  srx-server public IP

sudo ufw allow 80/tcp 443/tcp
docker compose up -d --build
docker compose logs -f
```

Caddy auto-issues a Let's Encrypt cert on first request.

## Local dev

```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install fastapi 'uvicorn[standard]' sqlalchemy pydantic pydantic-settings \
    'python-jose[cryptography]' httpx python-multipart bcrypt pyotp
uvicorn app.main:app --reload

cd frontend
npm install
npm run dev
```

## Routes

| Route | Purpose |
|---|---|
| `/login` | Password (+ optional 2FA) |
| `/morning` | Guided 4-step ritual (frog + supporting cast) |
| `/plan` | Today's tasks (max 5, exactly one frog) |
| `/focus?session=…&task=…` | Fullscreen pomodoro with wake-lock + context overlay |
| `/dictate?task=<id>` | Record → Groq Whisper → LLM outline → save to task |
| `/capture` | Inbox of intrusive thoughts (`⌘.` from anywhere) |
| `/review` | Daily + 7-day frog ratio |

## Hotkeys

- `⌘ .` / `Ctrl .` — open capture modal
- `⌘ ↵` inside capture — save
- `Esc` — close capture

## Backups

```bash
0 3 * * * docker exec focus-backend sqlite3 /data/focus.db ".backup /data/focus-$(date +\%F).db"
```

## Changing your password

```bash
python3 bin/hash-password.py
# update AUTH_PASSWORD_HASH in .env, then:
docker compose restart backend
# All existing sessions stay valid until JWT expiry (30d). To force logout
# everywhere, also rotate JWT_SECRET.
```

## Switching LLM providers

```env
# OpenRouter (chat only — keep WHISPER_MODEL on Groq)
LLM_BASE_URL=https://openrouter.ai/api/v1
LLM_MODEL=anthropic/claude-3.5-sonnet
LLM_API_KEY=sk-or-...
```

If splitting LLM and STT across vendors with separate keys, fork `backend/app/llm.py` and `backend/app/transcribe.py`.

## Roadmap

- [ ] Push notifications for body-double check-ins
- [ ] Streak with weekly forgiveness
- [ ] Optional `frog` CLI for personal Mac
- [ ] Per-month avoidance heatmap
